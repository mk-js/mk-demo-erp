package com.cobweb.erp.set.dao;

import com.mk.eap.entity.dao.EntityMapper;
import com.cobweb.erp.set.vo.SetDepartmentVo;

/**
 * @Title:       SysSetDepartmentMapper.java
 * @Package:     com.cobweb.erp.set.dao
 * @Description: 类文件概述
 * 
 * <p>
 * 	类文件详细描述
 * </p> 
 * 
 * @author lsg
 * 
 */
public interface SetDepartmentMapper  extends EntityMapper<SetDepartmentVo>{

}
