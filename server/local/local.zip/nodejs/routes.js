﻿module.exports = {
    "/": __dirname + "/html/",
}